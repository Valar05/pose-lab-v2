#!/usr/bin/env python3
"""
Heady Pose Lab V2 v03. Original invocation:
python - <<'PY'
from pathlib import Path
import zipfile,sys
p=Path.home()/'storage/downloads/Heady_GroundedIK_RuntimeTick_v03_Committable.zip'
with zipfile.ZipFile(p) as z: code=z.read('INSTALL_AND_COMMIT.py')
sys.argv=['INSTALL_AND_COMMIT.py',str(p)]
exec(compile(code,'INSTALL_AND_COMMIT.py','exec'),{'__name__':'__main__'})
PY
Copies the complete packet into the real LOCAL Pose Lab git checkout, verifies, commits
campaign-owned files only; DOES NOT run or regenerate old v05-v07 GIFs; NO GitHub push.
"""
import sys,os,json,hashlib,subprocess,zipfile,shutil,tempfile
from pathlib import Path

REL='tools/heady/campaigns/grounded_ik_v03'
RUNNER='tools/campaigns/heady_grounded_runtime_v03.sh'
EXPECTED_SOURCE='8785927ec1e8dd6c5f87eaa966b872bc7ebb42e7cf9a425f11cbbb3ff6a0fb27'

def fail(reason):
    print('STATUS=BLOCKED\nDIAGNOSIS='+str(reason),flush=True);sys.exit(2)
def sha(b):return hashlib.sha256(b).hexdigest()
def git(root,*args,check=True):
    x=subprocess.run(['git','-C',str(root),*args],capture_output=True,text=True)
    if check and x.returncode:fail('GIT '+ ' '.join(args)+' '+x.stderr.strip()[-500:])
    return x

def main():
    print('CAMPAIGN=HEADY_GROUNDED_IK_V03\nMODE=INSTALL_PRECOMPUTED_AND_COMMIT\nOLD_V05_V07_REEXECUTION=NO',flush=True)
    if len(sys.argv)<2:fail('ZIP_PATH_NOT_GIVEN')
    zpath=Path(sys.argv[1]).expanduser().resolve()
    if not zpath.is_file():fail('DOWNLOAD_ZIP_MISSING '+str(zpath))
    candidates=[]
    if os.environ.get('POSE_LAB_REPO'):candidates.append(Path(os.environ['POSE_LAB_REPO']))
    candidates.extend([Path.home()/'storage/documents/GodotProjects/pose-lab-v2',Path('/storage/emulated/0/Documents/GodotProjects/pose-lab-v2')])
    repo=next((p.resolve() for p in candidates if (p/'AGENTS.md').is_file() and (p/'docs/POSE_LAB_CAMPAIGN_RULES.md').is_file()),None)
    if repo is None:fail('CANONICAL_POSE_LAB_V2_REPO_NOT_FOUND')
    gr=git(repo,'rev-parse','--show-toplevel').stdout.strip()
    if Path(gr).resolve()!=repo:fail('TARGET_REPO_ROOT_MISMATCH')
    # Abort if another campaign is actively staging or touching our specific target. Never reset any dirty state.
    if git(repo,'diff','--cached','--name-only','--',REL,RUNNER).stdout.strip():fail('CAMPAIGN_PATH_HAS_STAGED_EDITS')
    if git(repo,'status','--porcelain','--',REL,RUNNER).stdout.strip():
        # Idempotent previous installed files are checked via bytes below, but uncommitted target edits are protected.
        fail('CAMPAIGN_PATH_HAS_UNCOMMITTED_EDITS')
    if git(repo,'var','GIT_AUTHOR_IDENT',check=False).returncode!=0:fail('GIT_AUTHOR_IDENTITY_MISSING')
    try:
      with zipfile.ZipFile(zpath) as z:
        bad=z.testzip()
        if bad:fail('BAD_ZIP_MEMBER '+bad)
        entries=[i for i in z.infolist() if not i.is_dir()]
        # No path traversal, links, duplicate file names, forbidden arbitrary content.
        paths=[i.filename for i in entries]
        if len(paths)!=len(set(paths)):fail('DUPLICATE_ZIP_MEMBERS')
        expected={REL+'/Meshy_AI_Character_output (1).glb',REL+'/FILES_SHA256.json',RUNNER,'INSTALL_AND_COMMIT.py'}
        if not expected.issubset(paths):fail('INCOMPLETE_PACKET')
        if any(p!='INSTALL_AND_COMMIT.py' and not (p.startswith(REL+'/') or p==RUNNER) for p in paths):fail('UNEXPECTED_ZIP_MEMBER')
        raw={p:z.read(p) for p in paths}
        if sha(raw[REL+'/Meshy_AI_Character_output (1).glb'])!=EXPECTED_SOURCE:fail('SOURCE_GLB_HASH_MISMATCH')
        h=json.loads(raw[REL+'/FILES_SHA256.json'])
        if any(sha(raw[REL+'/'+f])!=v for f,v in h.items()):fail('PACKET_CONTENT_HASH_MISMATCH')
    except Exception as e:fail('INVALID_ZIP '+str(e))
    # Preflight every destination: never clobber an independently modified tracked target.
    for rel,data in raw.items():
        if rel=='INSTALL_AND_COMMIT.py':continue
        p=repo/rel
        if p.exists() and p.read_bytes()!=data:fail('EXISTING_TARGET_DIFFERS '+rel)
    pkg=repo/REL/'SOURCE_PACKET.zip'
    archive=zpath.read_bytes()
    if pkg.exists() and pkg.read_bytes()!=archive:fail('PACKET_ARCHIVE_CONFLICT')
    todo=[(repo/r,v) for r,v in raw.items() if r!='INSTALL_AND_COMMIT.py']+[(pkg,archive)]
    modified=[]
    for target,data in todo:
        if target.exists():continue
        target.parent.mkdir(parents=True,exist_ok=True)
        with tempfile.NamedTemporaryFile('wb',dir=target.parent,delete=False) as f:
            f.write(data);f.flush();os.fsync(f.fileno());tmp=Path(f.name)
        os.replace(tmp,target);modified.append(target)
    # Campaign evidence has already been computed and hash-validated off-device;
    # verifying it here does not rerun earlier campaigns.
    for rel,b in raw.items():
        if rel!='INSTALL_AND_COMMIT.py' and sha((repo/rel).read_bytes())!=sha(b):fail('INSTALL_READBACK_MISMATCH '+rel)
    changes=git(repo,'status','--porcelain','--',REL,RUNNER).stdout.strip()
    if not changes:
        print('RESULT=ALREADY_INSTALLED_COMMITTED_NO_NEW_COMMIT')
    else:
        paths_to_add=[REL,RUNNER]
        git(repo,'add','--',*paths_to_add)
        # Commit only campaign-owned paths and leave unrelated staged files alone.
        before=git(repo,'rev-parse','HEAD').stdout.strip()
        git(repo,'commit','--only','-m','pose3d: preserve Heady grounded IK v03 runtime tick evidence','--',*paths_to_add)
        after=git(repo,'rev-parse','HEAD').stdout.strip()
        if before==after:fail('GIT_HEAD_UNCHANGED')
        print('LOCAL_COMMIT='+after)
    verify=repo/REL/'VERIFY_AND_SHOW.py'
    x=subprocess.run([sys.executable,str(verify),'show',str(repo/REL)],text=True,capture_output=True)
    print(x.stdout,end='')
    if x.returncode:fail('FINAL_VERIFY '+x.stderr.strip()[-500:])
    print('REPO='+str(repo))
    print('FULL_PACKET_IN_REPO='+str(pkg))
    print('REMOTE_PUSH=NOT_ATTEMPTED')
    print('STATUS=PASS_LOCAL_REPO_INSTALL_AND_COMMIT',flush=True)

if __name__=='__main__':main()
